setwd("C:\\Users\\it24100512\\Desktop\\IT24100512 LAB05")

getwd()

Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

fix(Delivery_Times)

attach(Delivery_Times)

histogram <- hist(Delivery_Time_.minutes., main ="deliver times", breaks = seq(20,70, length=10), right = FALSE)

freq <- histogram$counts

breaks <- histogram$breaks

cum.freq <- cumsum(freq)

new <- c()

for(i in 1:length(breaks)){
  if(i==1){
    new[i] <- 0
  } else {
    new[i] <- cum.freq[i-1]
  }
}

